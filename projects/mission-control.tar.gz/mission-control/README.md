# Mission Control

A centralized operations dashboard for managing phone networks, agency clients, and custom automation tools.

## Stack

- **Next.js 14** (App Router)
- **TypeScript**
- **Tailwind CSS** (dark slate/zinc theme)
- **shadcn/ui** components (manually integrated)
- **Lucide React** icons
- **Recharts** for charts
- **Zustand** for state management
- **SWR** (ready for future API integration)

## Getting Started

```bash
cd mission-control
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Pages

| Route | Description |
|---|---|
| `/` | Dashboard — stats, activity feed, project status, charts |
| `/phones` | Phone network — devices, jobs queue, logs, command modal |
| `/agency` | Agency — client list, task queue, create task modal |
| `/tools` | Tool builder — tool cards, new tool modal, run history |
| `/settings` | Settings — server config, API keys, notifications, theme |

## Project Structure

```
mission-control/
├── app/                    # Next.js App Router pages
│   ├── layout.tsx          # Root layout with sidebar
│   ├── page.tsx            # Dashboard
│   ├── phones/page.tsx
│   ├── agency/page.tsx
│   ├── tools/page.tsx
│   └── settings/page.tsx
├── components/
│   ├── layout/             # Sidebar, Header, PageWrapper
│   ├── dashboard/          # Stats, Activity, Charts, ProjectGrid
│   ├── phones/             # DeviceCard, JobQueue, Logs, CommandModal
│   ├── agency/             # ClientCard, TaskQueue
│   ├── tools/              # ToolCard, NewToolModal, RunHistory
│   ├── settings/           # Full settings panel
│   └── ui/                 # Shadcn UI primitives
├── lib/
│   ├── mock-data.ts        # All mock data (devices, jobs, clients, tools)
│   ├── types.ts            # TypeScript interfaces
│   └── utils.ts            # Helpers (cn, formatTimeAgo, etc.)
└── store/
    └── index.ts            # Zustand global store
```

## Features

- **Collapsible sidebar** with active route highlighting
- **Real-time-style UI** with colored status indicators
- **Dark theme** by default (slate-950 background)
- **Interactive command modal** for sending commands to devices
- **Task creation modal** with client/priority/platform selection
- **Tool builder modal** with code editor textarea
- **API key management** (add, show/hide, copy, delete)
- **Notification preferences** toggles
- **Mock data** for all entities — ready to swap for real API calls

## Adding Real Data

Replace `lib/mock-data.ts` imports in the Zustand store (`store/index.ts`) with SWR fetchers:

```typescript
// store/index.ts — swap mock init values with useSWR hooks in components
import useSWR from 'swr';

const fetcher = (url: string) => fetch(url).then(r => r.json());

// In a component:
const { data: devices } = useSWR('/api/devices', fetcher);
```

## Build

```bash
npm run build
npm start
```
