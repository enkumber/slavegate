import { create } from "zustand";
import type { Device, Job, Client, Task, Tool, Activity, Settings } from "@/lib/types";
import {
  mockDevices,
  mockJobs,
  mockClients,
  mockTasks,
  mockTools,
  mockActivities,
  mockSettings,
} from "@/lib/mock-data";

interface AppStore {
  // Data
  devices: Device[];
  jobs: Job[];
  clients: Client[];
  tasks: Task[];
  tools: Tool[];
  activities: Activity[];
  settings: Settings;

  // UI State
  sidebarCollapsed: boolean;
  selectedDeviceId: string | null;
  commandModalOpen: boolean;
  commandModalDeviceId: string | null;
  newToolModalOpen: boolean;

  // Actions
  setSidebarCollapsed: (collapsed: boolean) => void;
  toggleSidebar: () => void;
  setSelectedDevice: (id: string | null) => void;
  openCommandModal: (deviceId: string) => void;
  closeCommandModal: () => void;
  openNewToolModal: () => void;
  closeNewToolModal: () => void;

  // Data mutations
  addTool: (tool: Tool) => void;
  updateTool: (id: string, updates: Partial<Tool>) => void;
  addTask: (task: Task) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  updateSettings: (updates: Partial<Settings>) => void;
  removeApiKey: (id: string) => void;
}

export const useStore = create<AppStore>((set) => ({
  // Initial data
  devices: mockDevices,
  jobs: mockJobs,
  clients: mockClients,
  tasks: mockTasks,
  tools: mockTools,
  activities: mockActivities,
  settings: mockSettings,

  // UI State
  sidebarCollapsed: false,
  selectedDeviceId: null,
  commandModalOpen: false,
  commandModalDeviceId: null,
  newToolModalOpen: false,

  // UI Actions
  setSidebarCollapsed: (collapsed) => set({ sidebarCollapsed: collapsed }),
  toggleSidebar: () =>
    set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
  setSelectedDevice: (id) => set({ selectedDeviceId: id }),
  openCommandModal: (deviceId) =>
    set({ commandModalOpen: true, commandModalDeviceId: deviceId }),
  closeCommandModal: () =>
    set({ commandModalOpen: false, commandModalDeviceId: null }),
  openNewToolModal: () => set({ newToolModalOpen: true }),
  closeNewToolModal: () => set({ newToolModalOpen: false }),

  // Data mutations
  addTool: (tool) =>
    set((state) => ({ tools: [...state.tools, tool] })),
  updateTool: (id, updates) =>
    set((state) => ({
      tools: state.tools.map((t) => (t.id === id ? { ...t, ...updates } : t)),
    })),
  addTask: (task) =>
    set((state) => ({ tasks: [...state.tasks, task] })),
  updateTask: (id, updates) =>
    set((state) => ({
      tasks: state.tasks.map((t) => (t.id === id ? { ...t, ...updates } : t)),
    })),
  updateSettings: (updates) =>
    set((state) => ({ settings: { ...state.settings, ...updates } })),
  removeApiKey: (id) =>
    set((state) => ({
      settings: {
        ...state.settings,
        apiKeys: state.settings.apiKeys.filter((k) => k.id !== id),
      },
    })),
}));
