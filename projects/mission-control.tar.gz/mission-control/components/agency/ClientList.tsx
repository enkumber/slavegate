"use client";

import { UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStore } from "@/store";
import { ClientCard } from "./ClientCard";

export function ClientList() {
  const { clients } = useStore();

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-semibold text-slate-300">
          Clients ({clients.length})
        </h2>
        <Button size="sm" className="h-8 text-xs">
          <UserPlus className="w-3.5 h-3.5 mr-1.5" />
          Add Client
        </Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
        {clients.map((client) => (
          <ClientCard key={client.id} client={client} />
        ))}
      </div>
    </div>
  );
}
