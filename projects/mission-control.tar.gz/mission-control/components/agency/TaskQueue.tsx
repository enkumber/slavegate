"use client";

import { useState } from "react";
import { Plus, AlertCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useStore } from "@/store";
import { formatTimeAgo, getStatusBg, cn } from "@/lib/utils";
import type { Task, TaskStatus, TaskPriority } from "@/lib/types";

const priorityColors: Record<TaskPriority, string> = {
  low: "text-slate-500",
  medium: "text-blue-400",
  high: "text-yellow-400",
  urgent: "text-red-400",
};

const statusLabels: Record<TaskStatus, string> = {
  todo: "To Do",
  in_progress: "In Progress",
  done: "Done",
  blocked: "Blocked",
};

function TaskRow({ task }: { task: Task }) {
  return (
    <div className="flex items-center gap-3 py-2.5 border-b border-slate-800/60 last:border-0 hover:bg-slate-800/20 -mx-4 px-4 transition-colors">
      <div
        className={cn(
          "w-1.5 h-1.5 rounded-full flex-shrink-0",
          task.priority === "urgent"
            ? "bg-red-500"
            : task.priority === "high"
            ? "bg-yellow-500"
            : task.priority === "medium"
            ? "bg-blue-500"
            : "bg-slate-600"
        )}
      />
      <div className="flex-1 min-w-0">
        <p className="text-sm text-slate-200 font-medium truncate">
          {task.title}
        </p>
        <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
          <span>{task.clientName}</span>
          <span>·</span>
          <span>{task.platform}</span>
          <span>·</span>
          <span>Due {formatTimeAgo(task.dueDate)}</span>
        </div>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        <span
          className={cn(
            "text-[10px] font-medium capitalize",
            priorityColors[task.priority]
          )}
        >
          {task.priority}
        </span>
        <span
          className={cn(
            "text-[10px] font-medium px-2 py-0.5 rounded border",
            getStatusBg(task.status)
          )}
        >
          {statusLabels[task.status]}
        </span>
      </div>
    </div>
  );
}

export function TaskQueue() {
  const { tasks, clients, addTask } = useStore();
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    title: "",
    clientId: "",
    priority: "medium" as TaskPriority,
    platform: "",
    dueDate: "",
  });

  const handleCreate = () => {
    if (!form.title || !form.clientId) return;
    const client = clients.find((c) => c.id === form.clientId);
    const task: Task = {
      id: `task-${Date.now()}`,
      title: form.title,
      clientId: form.clientId,
      clientName: client?.name ?? "Unknown",
      status: "todo",
      priority: form.priority,
      dueDate: form.dueDate
        ? new Date(form.dueDate).toISOString()
        : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      assignedTo: "Dan",
      platform: form.platform || "General",
    };
    addTask(task);
    setModalOpen(false);
    setForm({ title: "", clientId: "", priority: "medium", platform: "", dueDate: "" });
  };

  const sortedTasks = [...tasks].sort((a, b) => {
    const order: Record<TaskStatus, number> = {
      blocked: 0,
      in_progress: 1,
      todo: 2,
      done: 3,
    };
    return order[a.status] - order[b.status];
  });

  return (
    <>
      <Card className="border-slate-800">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-semibold text-slate-200">
              Task Queue
            </CardTitle>
            <Button
              size="sm"
              className="h-8 text-xs"
              onClick={() => setModalOpen(true)}
            >
              <Plus className="w-3.5 h-3.5 mr-1" />
              Create Task
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="max-h-[360px] overflow-y-auto">
            {sortedTasks.length === 0 ? (
              <div className="py-8 text-center">
                <AlertCircle className="w-6 h-6 text-slate-700 mx-auto mb-2" />
                <p className="text-sm text-slate-600">No tasks</p>
              </div>
            ) : (
              sortedTasks.map((task) => (
                <TaskRow key={task.id} task={task} />
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Create Task Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Task</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-xs text-slate-400 mb-1.5 block">
                Task Title
              </Label>
              <Input
                placeholder="e.g. Create 5 Instagram Reels..."
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs text-slate-400 mb-1.5 block">
                  Client
                </Label>
                <Select
                  value={form.clientId}
                  onValueChange={(v) => setForm({ ...form, clientId: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select client" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs text-slate-400 mb-1.5 block">
                  Priority
                </Label>
                <Select
                  value={form.priority}
                  onValueChange={(v) =>
                    setForm({ ...form, priority: v as TaskPriority })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs text-slate-400 mb-1.5 block">
                  Platform
                </Label>
                <Input
                  placeholder="Instagram, TikTok..."
                  value={form.platform}
                  onChange={(e) => setForm({ ...form, platform: e.target.value })}
                />
              </div>
              <div>
                <Label className="text-xs text-slate-400 mb-1.5 block">
                  Due Date
                </Label>
                <Input
                  type="date"
                  value={form.dueDate}
                  onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
                  className="text-slate-300"
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" size="sm" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button size="sm" onClick={handleCreate} disabled={!form.title || !form.clientId}>
              Create Task
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
