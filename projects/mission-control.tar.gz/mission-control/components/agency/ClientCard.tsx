"use client";

import { Calendar, Instagram, Twitter, Youtube, Linkedin } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { formatTimeAgo, getStatusBg, cn } from "@/lib/utils";
import type { Client } from "@/lib/types";

const platformIcons: Record<string, React.ElementType> = {
  Instagram,
  TikTok: () => (
    <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-current">
      <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.65a8.18 8.18 0 004.79 1.53V6.72a4.85 4.85 0 01-1.02-.03z" />
    </svg>
  ),
  YouTube: Youtube,
  Twitter,
  LinkedIn: Linkedin,
  Pinterest: () => (
    <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-current">
      <path d="M12 0C5.373 0 0 5.373 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738a.36.36 0 01.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0z" />
    </svg>
  ),
};

interface ClientCardProps {
  client: Client;
}

export function ClientCard({ client }: ClientCardProps) {
  const progress = Math.round(
    (client.completedPosts / client.monthlyPosts) * 100
  );

  return (
    <Card className="border-slate-800 hover:border-slate-700 transition-colors">
      <CardContent className="p-4">
        {/* Header */}
        <div className="flex items-start gap-3 mb-4">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center text-sm font-bold text-white flex-shrink-0">
            {client.avatar}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-sm font-semibold text-white leading-none">
                  {client.name}
                </p>
                <p className="text-xs text-slate-500 mt-0.5">{client.company}</p>
              </div>
              <span
                className={cn(
                  "flex-shrink-0 text-[10px] font-medium px-2 py-0.5 rounded border capitalize",
                  getStatusBg(client.status)
                )}
              >
                {client.status}
              </span>
            </div>
          </div>
        </div>

        {/* Platforms */}
        <div className="flex items-center gap-2 mb-3">
          {client.platforms.map((platform) => {
            const Icon = platformIcons[platform];
            return Icon ? (
              <div
                key={platform}
                className="w-6 h-6 bg-slate-800 rounded-md flex items-center justify-center text-slate-400"
                title={platform}
              >
                <Icon />
              </div>
            ) : (
              <span
                key={platform}
                className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded"
              >
                {platform}
              </span>
            );
          })}
        </div>

        {/* Posts progress */}
        <div className="mb-3">
          <div className="flex justify-between text-[11px] mb-1">
            <span className="text-slate-500">Monthly posts</span>
            <span className="text-slate-300 font-medium">
              {client.completedPosts}/{client.monthlyPosts}
            </span>
          </div>
          <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full bg-blue-500 transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="text-right text-[10px] text-slate-600 mt-0.5">
            {progress}% complete
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800">
          <div className="flex items-center gap-1.5">
            <div
              className={cn(
                "text-[10px] px-2 py-0.5 rounded border font-medium",
                client.strategyStatus === "approved"
                  ? "bg-green-500/10 text-green-400 border-green-500/20"
                  : client.strategyStatus === "review"
                  ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"
                  : "bg-slate-500/10 text-slate-400 border-slate-500/20"
              )}
            >
              Strategy: {client.strategyStatus}
            </div>
          </div>
          {client.nextScheduledPost ? (
            <div className="flex items-center gap-1 text-[11px] text-slate-500">
              <Calendar className="w-3 h-3" />
              <span>{formatTimeAgo(client.nextScheduledPost)}</span>
            </div>
          ) : (
            <span className="text-[11px] text-slate-600 italic">Not scheduled</span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
