"use client";

import { Bell, Menu, Search } from "lucide-react";
import { useStore } from "@/store";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  title: string;
  subtitle?: string;
}

export function Header({ title, subtitle }: HeaderProps) {
  const { toggleSidebar, activities } = useStore();

  const pendingAlerts = activities.filter(
    (a) => a.severity === "error" || a.severity === "warning"
  ).length;

  return (
    <header className="flex items-center justify-between h-14 px-4 border-b border-slate-800 bg-slate-950/80 backdrop-blur-sm">
      {/* Left side */}
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden text-slate-400 hover:text-white"
          onClick={toggleSidebar}
        >
          <Menu className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-sm font-semibold text-white leading-none">
            {title}
          </h1>
          {subtitle && (
            <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>
          )}
        </div>
      </div>

      {/* Right side */}
      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          className="text-slate-400 hover:text-white"
        >
          <Search className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="relative text-slate-400 hover:text-white"
        >
          <Bell className="w-4 h-4" />
          {pendingAlerts > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-slate-950" />
          )}
        </Button>
        <div className="w-7 h-7 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-[11px] font-bold text-white ml-1">
          D
        </div>
      </div>
    </header>
  );
}
