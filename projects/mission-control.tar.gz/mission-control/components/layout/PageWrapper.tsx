import { cn } from "@/lib/utils";

interface PageWrapperProps {
  children: React.ReactNode;
  className?: string;
}

export function PageWrapper({ children, className }: PageWrapperProps) {
  return (
    <div
      className={cn(
        "flex-1 overflow-y-auto p-4 md:p-6 space-y-5",
        className
      )}
    >
      {children}
    </div>
  );
}
