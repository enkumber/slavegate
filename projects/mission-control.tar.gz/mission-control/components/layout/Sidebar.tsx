"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Smartphone,
  Briefcase,
  Wrench,
  Settings,
  ChevronLeft,
  ChevronRight,
  Zap,
  Activity,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useStore } from "@/store";

const navItems = [
  {
    label: "Dashboard",
    href: "/",
    icon: LayoutDashboard,
  },
  {
    label: "Phone Network",
    href: "/phones",
    icon: Smartphone,
  },
  {
    label: "Agency",
    href: "/agency",
    icon: Briefcase,
  },
  {
    label: "Tool Builder",
    href: "/tools",
    icon: Wrench,
  },
  {
    label: "Settings",
    href: "/settings",
    icon: Settings,
  },
];

export function Sidebar() {
  const pathname = usePathname();
  const { sidebarCollapsed, toggleSidebar } = useStore();

  return (
    <aside
      className={cn(
        "relative flex flex-col h-full bg-slate-950 border-r border-slate-800 transition-all duration-300 ease-in-out",
        sidebarCollapsed ? "w-16" : "w-56"
      )}
    >
      {/* Logo */}
      <div className="flex items-center h-14 px-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5 overflow-hidden">
          <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <Zap className="w-4 h-4 text-white" />
          </div>
          {!sidebarCollapsed && (
            <div className="min-w-0">
              <span className="font-bold text-sm text-white tracking-tight">
                Mission Control
              </span>
              <div className="flex items-center gap-1">
                <Activity className="w-2.5 h-2.5 text-green-400" />
                <span className="text-[10px] text-green-400 font-medium">
                  LIVE
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-3 overflow-hidden">
        <ul className="space-y-0.5 px-2">
          {navItems.map((item) => {
            const isActive =
              item.href === "/"
                ? pathname === "/"
                : pathname.startsWith(item.href);
            const Icon = item.icon;

            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 px-2 py-2 rounded-lg text-sm font-medium transition-colors group",
                    isActive
                      ? "bg-blue-600/20 text-blue-400 border border-blue-600/30"
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
                  )}
                  title={sidebarCollapsed ? item.label : undefined}
                >
                  <Icon
                    className={cn(
                      "flex-shrink-0 w-4 h-4",
                      isActive ? "text-blue-400" : "text-slate-500 group-hover:text-slate-300"
                    )}
                  />
                  {!sidebarCollapsed && (
                    <span className="truncate">{item.label}</span>
                  )}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Footer */}
      {!sidebarCollapsed && (
        <div className="px-3 py-3 border-t border-slate-800">
          <div className="text-[10px] text-slate-600 font-mono">
            v0.1.0 — dev
          </div>
        </div>
      )}

      {/* Collapse toggle */}
      <button
        onClick={toggleSidebar}
        className="absolute -right-3 top-[4.5rem] z-10 w-6 h-6 bg-slate-800 border border-slate-700 rounded-full flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
        aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
      >
        {sidebarCollapsed ? (
          <ChevronRight className="w-3 h-3" />
        ) : (
          <ChevronLeft className="w-3 h-3" />
        )}
      </button>
    </aside>
  );
}
