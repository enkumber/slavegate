"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadialBarChart,
  RadialBar,
  Legend,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { mockDailyJobStats, mockUptimeStats } from "@/lib/mock-data";

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs shadow-xl">
        <p className="font-semibold text-slate-200 mb-1.5">{label}</p>
        {payload.map((entry: any) => (
          <div key={entry.name} className="flex items-center gap-2">
            <span
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: entry.color }}
            />
            <span className="text-slate-400 capitalize">{entry.name}:</span>
            <span className="font-semibold text-white">{entry.value}</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export function JobsChart() {
  return (
    <Card className="border-slate-800">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold text-slate-200">
          Jobs — Last 7 Days
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <ResponsiveContainer width="100%" height={180}>
          <BarChart
            data={mockDailyJobStats}
            margin={{ top: 4, right: 4, left: -20, bottom: 0 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis
              dataKey="date"
              tick={{ fill: "#64748b", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              tick={{ fill: "#64748b", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="done" name="done" fill="#22c55e" radius={[2, 2, 0, 0]} stackId="a" />
            <Bar dataKey="running" name="running" fill="#3b82f6" radius={[0, 0, 0, 0]} stackId="a" />
            <Bar dataKey="failed" name="failed" fill="#ef4444" radius={[0, 0, 0, 0]} stackId="a" />
            <Bar dataKey="pending" name="pending" fill="#64748b" radius={[2, 2, 0, 0]} stackId="a" />
          </BarChart>
        </ResponsiveContainer>

        {/* Legend */}
        <div className="flex items-center gap-4 mt-2 px-1">
          {[
            { color: "#22c55e", label: "Done" },
            { color: "#3b82f6", label: "Running" },
            { color: "#ef4444", label: "Failed" },
            { color: "#64748b", label: "Pending" },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-1.5">
              <span
                className="w-2 h-2 rounded-sm"
                style={{ backgroundColor: item.color }}
              />
              <span className="text-[11px] text-slate-500">{item.label}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export function UptimeChart() {
  return (
    <Card className="border-slate-800">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold text-slate-200">
          Device Uptime (7d)
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-2.5">
          {mockUptimeStats.map((stat) => (
            <div key={stat.device}>
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs text-slate-400 truncate max-w-[120px]">
                  {stat.device}
                </span>
                <span
                  className={`text-xs font-semibold tabular-nums ${
                    stat.uptime >= 90
                      ? "text-green-400"
                      : stat.uptime >= 75
                      ? "text-yellow-400"
                      : "text-red-400"
                  }`}
                >
                  {stat.uptime}%
                </span>
              </div>
              <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${
                    stat.uptime >= 90
                      ? "bg-green-500"
                      : stat.uptime >= 75
                      ? "bg-yellow-500"
                      : "bg-red-500"
                  }`}
                  style={{ width: `${stat.uptime}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
