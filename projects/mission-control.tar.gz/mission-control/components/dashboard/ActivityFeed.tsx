"use client";

import {
  Smartphone,
  Play,
  CheckCircle,
  XCircle,
  UserPlus,
  Wrench,
  AlertTriangle,
  Info,
  Wifi,
  WifiOff,
  CheckSquare,
  PlusSquare,
  Server,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useStore } from "@/store";
import { formatTimeAgo, cn } from "@/lib/utils";
import type { Activity } from "@/lib/types";

const activityIcons: Record<string, React.ElementType> = {
  device_online: Wifi,
  device_offline: WifiOff,
  job_started: Play,
  job_completed: CheckCircle,
  job_failed: XCircle,
  client_added: UserPlus,
  task_created: PlusSquare,
  task_completed: CheckSquare,
  tool_run: Wrench,
  alert: AlertTriangle,
  system: Server,
};

const severityStyles: Record<string, string> = {
  info: "text-blue-400 bg-blue-500/10",
  success: "text-green-400 bg-green-500/10",
  warning: "text-yellow-400 bg-yellow-500/10",
  error: "text-red-400 bg-red-500/10",
};

const projectBadge: Record<string, string> = {
  phones: "bg-blue-500/10 text-blue-400",
  agency: "bg-purple-500/10 text-purple-400",
  tools: "bg-orange-500/10 text-orange-400",
  system: "bg-slate-500/10 text-slate-400",
};

function ActivityItem({ activity }: { activity: Activity }) {
  const Icon = activityIcons[activity.type] ?? Info;
  const severityStyle = severityStyles[activity.severity] ?? severityStyles.info;

  return (
    <div className="flex gap-3 py-2.5 border-b border-slate-800/60 last:border-0">
      <div
        className={cn(
          "flex-shrink-0 w-7 h-7 rounded-lg flex items-center justify-center mt-0.5",
          severityStyle
        )}
      >
        <Icon className="w-3.5 h-3.5" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <p className="text-sm text-slate-200 font-medium leading-snug">
            {activity.title}
          </p>
          <span className="flex-shrink-0 text-[11px] text-slate-600 mt-0.5 tabular-nums">
            {formatTimeAgo(activity.timestamp)}
          </span>
        </div>
        <p className="text-xs text-slate-500 mt-0.5 truncate">
          {activity.description}
        </p>
        <span
          className={cn(
            "inline-block text-[10px] font-medium px-1.5 py-0.5 rounded mt-1",
            projectBadge[activity.project]
          )}
        >
          {activity.project}
        </span>
      </div>
    </div>
  );
}

export function ActivityFeed() {
  const { activities } = useStore();
  const sorted = [...activities].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  return (
    <Card className="border-slate-800">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-semibold text-slate-200">
            Activity Feed
          </CardTitle>
          <span className="text-[11px] text-slate-500">
            {activities.length} events
          </span>
        </div>
      </CardHeader>
      <CardContent className="pt-0 px-4">
        <div className="max-h-[420px] overflow-y-auto -mx-1 px-1 space-y-0">
          {sorted.slice(0, 15).map((activity) => (
            <ActivityItem key={activity.id} activity={activity} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
