"use client";

import { Smartphone, Briefcase, Play, AlertTriangle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useStore } from "@/store";

export function StatsCards() {
  const { devices, jobs, clients, activities } = useStore();

  const activeDevices = devices.filter(
    (d) => d.status === "online" || d.status === "busy"
  ).length;
  const runningJobs = jobs.filter((j) => j.status === "running").length;
  const activeClients = clients.filter((c) => c.status === "active").length;
  const pendingAlerts = activities.filter(
    (a) => a.severity === "error" || a.severity === "warning"
  ).length;

  const stats = [
    {
      label: "Active Devices",
      value: activeDevices,
      total: devices.length,
      icon: Smartphone,
      color: "text-green-400",
      bg: "bg-green-500/10",
      border: "border-green-500/20",
      trend: "+1 from yesterday",
    },
    {
      label: "Running Jobs",
      value: runningJobs,
      total: jobs.filter((j) => j.status === "pending" || j.status === "running").length,
      icon: Play,
      color: "text-blue-400",
      bg: "bg-blue-500/10",
      border: "border-blue-500/20",
      trend: "2 pending in queue",
    },
    {
      label: "Active Clients",
      value: activeClients,
      total: clients.length,
      icon: Briefcase,
      color: "text-purple-400",
      bg: "bg-purple-500/10",
      border: "border-purple-500/20",
      trend: "1 onboarding",
    },
    {
      label: "Pending Alerts",
      value: pendingAlerts,
      total: null,
      icon: AlertTriangle,
      color: pendingAlerts > 0 ? "text-red-400" : "text-slate-400",
      bg: pendingAlerts > 0 ? "bg-red-500/10" : "bg-slate-500/10",
      border: pendingAlerts > 0 ? "border-red-500/20" : "border-slate-500/20",
      trend: pendingAlerts > 0 ? "Needs attention" : "All clear",
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat) => {
        const Icon = stat.icon;
        return (
          <Card key={stat.label} className="border-slate-800">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-slate-500 font-medium mb-1">
                    {stat.label}
                  </p>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-2xl font-bold text-white tabular-nums">
                      {stat.value}
                    </span>
                    {stat.total !== null && (
                      <span className="text-sm text-slate-600">
                        / {stat.total}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1">
                    {stat.trend}
                  </p>
                </div>
                <div
                  className={`w-9 h-9 rounded-lg ${stat.bg} border ${stat.border} flex items-center justify-center`}
                >
                  <Icon className={`w-4 h-4 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
