"use client";

import Link from "next/link";
import { Smartphone, Briefcase, Home, ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useStore } from "@/store";
import { cn } from "@/lib/utils";

export function ProjectGrid() {
  const { devices, jobs, clients } = useStore();

  const onlineDevices = devices.filter(
    (d) => d.status === "online" || d.status === "busy"
  ).length;
  const errorDevices = devices.filter((d) => d.status === "error").length;
  const runningJobs = jobs.filter((j) => j.status === "running").length;
  const failedJobs = jobs.filter((j) => j.status === "failed").length;
  const activeClients = clients.filter((c) => c.status === "active").length;

  const projects = [
    {
      name: "Phone Network",
      href: "/phones",
      icon: Smartphone,
      color: "text-blue-400",
      bg: "bg-blue-500/10",
      border: "border-blue-500/20",
      status: errorDevices > 0 ? "degraded" : "operational",
      stats: [
        { label: "Online", value: onlineDevices, total: devices.length },
        { label: "Running Jobs", value: runningJobs },
      ],
      description: `${devices.length} devices managed`,
    },
    {
      name: "Agency",
      href: "/agency",
      icon: Briefcase,
      color: "text-purple-400",
      bg: "bg-purple-500/10",
      border: "border-purple-500/20",
      status: "operational" as const,
      stats: [
        { label: "Active Clients", value: activeClients, total: clients.length },
        { label: "Tasks Due", value: 2 },
      ],
      description: `${clients.length} clients`,
    },
    {
      name: "Apartment",
      href: "#",
      icon: Home,
      color: "text-emerald-400",
      bg: "bg-emerald-500/10",
      border: "border-emerald-500/20",
      status: "operational" as const,
      stats: [
        { label: "Tenants", value: 4 },
        { label: "Pending", value: 1 },
      ],
      description: "Property management",
    },
  ];

  const statusColors: Record<string, string> = {
    operational: "bg-green-500",
    degraded: "bg-yellow-500",
    down: "bg-red-500",
  };

  const statusLabels: Record<string, string> = {
    operational: "Operational",
    degraded: "Degraded",
    down: "Down",
  };

  return (
    <Card className="border-slate-800">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-slate-200">
          Project Status
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0 space-y-3">
        {projects.map((project) => {
          const Icon = project.icon;
          return (
            <Link
              key={project.name}
              href={project.href}
              className="flex items-center gap-4 p-3 rounded-lg border border-slate-800 hover:border-slate-700 hover:bg-slate-800/30 transition-all group"
            >
              <div
                className={cn(
                  "w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0",
                  project.bg,
                  `border ${project.border}`
                )}
              >
                <Icon className={cn("w-4 h-4", project.color)} />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="text-sm font-medium text-slate-200">
                    {project.name}
                  </span>
                  <span className="flex items-center gap-1">
                    <span
                      className={cn(
                        "w-1.5 h-1.5 rounded-full",
                        statusColors[project.status]
                      )}
                    />
                    <span className="text-[10px] text-slate-500">
                      {statusLabels[project.status]}
                    </span>
                  </span>
                </div>
                <p className="text-xs text-slate-500">{project.description}</p>
                <div className="flex gap-4 mt-1.5">
                  {project.stats.map((stat) => (
                    <div key={stat.label} className="text-xs">
                      <span className="font-semibold text-slate-300">
                        {stat.value}
                        {stat.total !== undefined && (
                          <span className="text-slate-600">/{stat.total}</span>
                        )}
                      </span>
                      <span className="text-slate-600 ml-1">{stat.label}</span>
                    </div>
                  ))}
                </div>
              </div>

              <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-slate-400 transition-colors flex-shrink-0" />
            </Link>
          );
        })}
      </CardContent>
    </Card>
  );
}
