"use client";

import { useState } from "react";
import { Terminal, Send, Cpu } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useStore } from "@/store";

const quickCommands = [
  { label: "Status Check", cmd: "status" },
  { label: "Restart App", cmd: "restart_app" },
  { label: "Clear Cache", cmd: "clear_cache" },
  { label: "Take Screenshot", cmd: "screenshot" },
  { label: "Get Battery", cmd: "battery_info" },
  { label: "List Jobs", cmd: "list_jobs" },
];

export function CommandModal() {
  const { commandModalOpen, commandModalDeviceId, closeCommandModal, devices } =
    useStore();
  const [command, setCommand] = useState("");
  const [output, setOutput] = useState<string | null>(null);
  const [isRunning, setIsRunning] = useState(false);

  const device = devices.find((d) => d.id === commandModalDeviceId);

  const handleSend = async () => {
    if (!command.trim()) return;
    setIsRunning(true);
    setOutput(null);

    // Simulate command execution
    await new Promise((r) => setTimeout(r, 1200));
    const mockOutputs: Record<string, string> = {
      status: `Device: ${device?.name}\nOS: ${device?.os}\nBattery: ${device?.battery}%\nIP: ${device?.ip}\nStatus: ${device?.status}`,
      restart_app: `Restarting application...\nStopping current job...\nApp restarted successfully.`,
      clear_cache: `Clearing cache...\nCache cleared. 142 MB freed.`,
      screenshot: `Taking screenshot...\nSaved to /storage/screenshots/screen_${Date.now()}.png`,
      battery_info: `Battery Level: ${device?.battery}%\nCharging: No\nHealth: Good\nTemp: 32°C`,
      list_jobs: `No jobs in local queue.\nFetching from server...`,
    };
    setOutput(
      mockOutputs[command.trim()] ??
        `$ ${command}\nCommand executed successfully.\nExit code: 0`
    );
    setIsRunning(false);
  };

  const handleClose = () => {
    closeCommandModal();
    setCommand("");
    setOutput(null);
  };

  return (
    <Dialog open={commandModalOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-blue-400" />
            Send Command
            {device && (
              <span className="text-slate-500 font-normal text-sm">
                → {device.name}
              </span>
            )}
          </DialogTitle>
        </DialogHeader>

        {device && (
          <div className="flex items-center gap-2 p-2.5 bg-slate-800/50 rounded-lg border border-slate-700">
            <Cpu className="w-4 h-4 text-slate-500" />
            <div className="flex-1 min-w-0 text-xs">
              <span className="text-slate-300 font-medium">{device.model}</span>
              <span className="text-slate-500 ml-2">{device.ip}</span>
            </div>
            <span
              className={`text-[10px] px-1.5 py-0.5 rounded font-medium capitalize ${
                device.status === "online"
                  ? "text-green-400 bg-green-500/10"
                  : "text-yellow-400 bg-yellow-500/10"
              }`}
            >
              {device.status}
            </span>
          </div>
        )}

        {/* Quick commands */}
        <div>
          <p className="text-xs text-slate-500 mb-2">Quick commands</p>
          <div className="flex flex-wrap gap-1.5">
            {quickCommands.map((qc) => (
              <button
                key={qc.cmd}
                onClick={() => setCommand(qc.cmd)}
                className="text-xs px-2.5 py-1 rounded-md bg-slate-800 border border-slate-700 text-slate-400 hover:text-white hover:border-slate-600 transition-colors"
              >
                {qc.label}
              </button>
            ))}
          </div>
        </div>

        {/* Command input */}
        <div>
          <p className="text-xs text-slate-500 mb-1.5">Command</p>
          <Textarea
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            placeholder="Enter command..."
            className="font-mono text-sm h-20 resize-none"
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
                handleSend();
              }
            }}
          />
          <p className="text-[10px] text-slate-600 mt-1">Ctrl+Enter to send</p>
        </div>

        {/* Output */}
        {(output || isRunning) && (
          <div className="bg-slate-950 rounded-lg border border-slate-800 p-3">
            <p className="text-[10px] text-slate-500 mb-2 font-semibold uppercase tracking-wider">
              Output
            </p>
            {isRunning ? (
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" />
                <span className="text-xs text-slate-500">Executing...</span>
              </div>
            ) : (
              <pre className="text-xs text-green-400 font-mono whitespace-pre-wrap">
                {output}
              </pre>
            )}
          </div>
        )}

        <DialogFooter>
          <Button variant="ghost" size="sm" onClick={handleClose}>
            Cancel
          </Button>
          <Button
            size="sm"
            onClick={handleSend}
            disabled={!command.trim() || isRunning}
          >
            <Send className="w-3.5 h-3.5 mr-1.5" />
            {isRunning ? "Sending..." : "Send"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
