"use client";

import { useState } from "react";
import { Search, Filter } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { mockLogs } from "@/lib/mock-data";
import { formatTimeAgo, cn } from "@/lib/utils";

const levelColors: Record<string, string> = {
  INFO: "text-blue-400",
  WARN: "text-yellow-400",
  ERROR: "text-red-400",
  DEBUG: "text-slate-500",
};

const levelBg: Record<string, string> = {
  INFO: "bg-blue-500/10",
  WARN: "bg-yellow-500/10",
  ERROR: "bg-red-500/10",
  DEBUG: "bg-slate-500/10",
};

export function LogsPanel() {
  const [filter, setFilter] = useState("");
  const [levelFilter, setLevelFilter] = useState<string>("ALL");

  const levels = ["ALL", "INFO", "WARN", "ERROR"];

  const filtered = mockLogs.filter((log) => {
    const matchesText =
      filter === "" ||
      log.message.toLowerCase().includes(filter.toLowerCase()) ||
      log.device.toLowerCase().includes(filter.toLowerCase());
    const matchesLevel = levelFilter === "ALL" || log.level === levelFilter;
    return matchesText && matchesLevel;
  });

  return (
    <Card className="border-slate-800">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-3">
          <CardTitle className="text-sm font-semibold text-slate-200">
            Device Logs
          </CardTitle>
          <div className="flex items-center gap-2">
            {/* Level filter */}
            <div className="flex items-center gap-1">
              {levels.map((level) => (
                <button
                  key={level}
                  onClick={() => setLevelFilter(level)}
                  className={cn(
                    "text-[10px] px-2 py-0.5 rounded font-medium transition-colors",
                    levelFilter === level
                      ? level === "ALL"
                        ? "bg-slate-600 text-white"
                        : `${levelBg[level]} ${levelColors[level]}`
                      : "text-slate-600 hover:text-slate-400"
                  )}
                >
                  {level}
                </button>
              ))}
            </div>
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-500" />
              <Input
                placeholder="Filter logs..."
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="pl-7 h-7 text-xs w-44"
              />
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="bg-slate-950 rounded-lg border border-slate-800 overflow-hidden">
          <div className="max-h-56 overflow-y-auto">
            {filtered.length === 0 ? (
              <div className="py-6 text-center">
                <p className="text-xs text-slate-600">No matching logs</p>
              </div>
            ) : (
              <table className="w-full text-xs font-mono">
                <tbody>
                  {filtered.map((log) => (
                    <tr
                      key={log.id}
                      className="border-b border-slate-800/50 last:border-0 hover:bg-slate-800/20 transition-colors"
                    >
                      <td className="py-1.5 px-3 text-slate-600 whitespace-nowrap w-24">
                        {formatTimeAgo(log.timestamp)}
                      </td>
                      <td className="py-1.5 px-2 whitespace-nowrap">
                        <span
                          className={cn(
                            "px-1.5 py-0.5 rounded text-[10px] font-semibold",
                            levelBg[log.level],
                            levelColors[log.level]
                          )}
                        >
                          {log.level}
                        </span>
                      </td>
                      <td className="py-1.5 px-2 text-slate-500 whitespace-nowrap">
                        {log.device}
                      </td>
                      <td className="py-1.5 px-3 text-slate-300">
                        {log.message}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
