"use client";

import { useState } from "react";
import { Clock, CheckCircle, XCircle, Loader2, AlertCircle } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useStore } from "@/store";
import { formatTimeAgo, formatDuration, getStatusBg, cn } from "@/lib/utils";
import type { Job, JobStatus } from "@/lib/types";

const statusIcons: Record<JobStatus, React.ElementType> = {
  pending: Clock,
  running: Loader2,
  done: CheckCircle,
  failed: XCircle,
};

function JobRow({ job }: { job: Job }) {
  const Icon = statusIcons[job.status];
  return (
    <div className="flex items-center gap-3 py-2.5 border-b border-slate-800/60 last:border-0 hover:bg-slate-800/20 -mx-4 px-4 transition-colors">
      <Icon
        className={cn(
          "w-4 h-4 flex-shrink-0",
          job.status === "done"
            ? "text-green-400"
            : job.status === "failed"
            ? "text-red-400"
            : job.status === "running"
            ? "text-blue-400 animate-spin"
            : "text-slate-500"
        )}
      />
      <div className="flex-1 min-w-0">
        <p className="text-sm text-slate-200 font-medium truncate">{job.name}</p>
        <p className="text-xs text-slate-500">
          {job.deviceName}
          {job.startedAt && (
            <> · Started {formatTimeAgo(job.startedAt)}</>
          )}
          {job.duration !== null && (
            <> · {formatDuration(job.duration)}</>
          )}
        </p>
        {(job.output || job.error) && (
          <p
            className={cn(
              "text-[11px] mt-0.5 truncate",
              job.error ? "text-red-400" : "text-slate-500"
            )}
          >
            {job.error ?? job.output}
          </p>
        )}
      </div>
      <span
        className={cn(
          "flex-shrink-0 text-[10px] font-medium px-2 py-0.5 rounded border capitalize",
          getStatusBg(job.status)
        )}
      >
        {job.status}
      </span>
    </div>
  );
}

export function JobQueue() {
  const { jobs } = useStore();

  const byStatus = {
    all: jobs,
    pending: jobs.filter((j) => j.status === "pending"),
    running: jobs.filter((j) => j.status === "running"),
    done: jobs.filter((j) => j.status === "done"),
    failed: jobs.filter((j) => j.status === "failed"),
  };

  return (
    <Card className="border-slate-800">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-semibold text-slate-200">
            Job Queue
          </CardTitle>
          <div className="flex items-center gap-2 text-[11px]">
            <span className="text-blue-400 font-semibold">{byStatus.running.length} running</span>
            <span className="text-slate-600">·</span>
            <span className="text-slate-500">{byStatus.pending.length} pending</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <Tabs defaultValue="all">
          <TabsList className="mb-3">
            <TabsTrigger value="all" className="text-xs">
              All ({byStatus.all.length})
            </TabsTrigger>
            <TabsTrigger value="running" className="text-xs">
              Running ({byStatus.running.length})
            </TabsTrigger>
            <TabsTrigger value="pending" className="text-xs">
              Pending ({byStatus.pending.length})
            </TabsTrigger>
            <TabsTrigger value="done" className="text-xs">
              Done ({byStatus.done.length})
            </TabsTrigger>
            <TabsTrigger value="failed" className="text-xs">
              Failed ({byStatus.failed.length})
            </TabsTrigger>
          </TabsList>

          {(Object.entries(byStatus) as [string, Job[]][]).map(
            ([status, jobList]) => (
              <TabsContent key={status} value={status} className="mt-0">
                <div className="max-h-[320px] overflow-y-auto">
                  {jobList.length === 0 ? (
                    <div className="py-8 text-center">
                      <AlertCircle className="w-6 h-6 text-slate-700 mx-auto mb-2" />
                      <p className="text-sm text-slate-600">
                        No {status} jobs
                      </p>
                    </div>
                  ) : (
                    jobList.map((job) => <JobRow key={job.id} job={job} />)
                  )}
                </div>
              </TabsContent>
            )
          )}
        </Tabs>
      </CardContent>
    </Card>
  );
}
