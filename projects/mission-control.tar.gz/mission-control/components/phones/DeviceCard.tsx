"use client";

import {
  Battery,
  BatteryLow,
  BatteryMedium,
  BatteryFull,
  Wifi,
  WifiOff,
  Terminal,
  Clock,
  Cpu,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useStore } from "@/store";
import { formatTimeAgo, getStatusBg, cn } from "@/lib/utils";
import type { Device } from "@/lib/types";

interface DeviceCardProps {
  device: Device;
}

function BatteryIcon({ level }: { level: number }) {
  if (level <= 20) return <BatteryLow className="w-3.5 h-3.5 text-red-400" />;
  if (level <= 50) return <BatteryMedium className="w-3.5 h-3.5 text-yellow-400" />;
  return <BatteryFull className="w-3.5 h-3.5 text-green-400" />;
}

const statusDot: Record<string, string> = {
  online: "bg-green-500 status-online",
  offline: "bg-slate-600",
  busy: "bg-yellow-500",
  error: "bg-red-500",
};

export function DeviceCard({ device }: DeviceCardProps) {
  const { openCommandModal, jobs } = useStore();

  const currentJob = device.currentJob
    ? jobs.find((j) => j.id === device.currentJob)
    : null;

  return (
    <Card className="border-slate-800 hover:border-slate-700 transition-colors">
      <CardContent className="p-4">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className="w-9 h-9 bg-slate-800 rounded-lg flex items-center justify-center">
                <Cpu className="w-4 h-4 text-slate-400" />
              </div>
              <span
                className={cn(
                  "absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-slate-900",
                  statusDot[device.status]
                )}
              />
            </div>
            <div>
              <p className="text-sm font-semibold text-white leading-none">
                {device.name}
              </p>
              <p className="text-xs text-slate-500 mt-0.5">{device.model}</p>
            </div>
          </div>
          <span
            className={cn(
              "text-[10px] font-medium px-2 py-0.5 rounded-md border capitalize",
              getStatusBg(device.status)
            )}
          >
            {device.status}
          </span>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 gap-2 mb-3">
          <div className="bg-slate-800/40 rounded-lg p-2">
            <p className="text-[10px] text-slate-500 mb-0.5">Battery</p>
            <div className="flex items-center gap-1.5">
              <BatteryIcon level={device.battery} />
              <span
                className={cn(
                  "text-sm font-semibold tabular-nums",
                  device.battery <= 20
                    ? "text-red-400"
                    : device.battery <= 50
                    ? "text-yellow-400"
                    : "text-green-400"
                )}
              >
                {device.battery}%
              </span>
            </div>
          </div>
          <div className="bg-slate-800/40 rounded-lg p-2">
            <p className="text-[10px] text-slate-500 mb-0.5">Last Seen</p>
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-slate-500" />
              <span className="text-xs text-slate-300">
                {formatTimeAgo(device.lastSeen)}
              </span>
            </div>
          </div>
        </div>

        {/* Current job */}
        <div className="mb-3 bg-slate-800/40 rounded-lg p-2 min-h-[40px]">
          {currentJob ? (
            <>
              <p className="text-[10px] text-slate-500 mb-0.5">Current Job</p>
              <p className="text-xs text-blue-300 font-medium truncate">
                {currentJob.name}
              </p>
              {currentJob.output && (
                <p className="text-[10px] text-slate-500 truncate mt-0.5">
                  {currentJob.output}
                </p>
              )}
            </>
          ) : (
            <div className="flex items-center gap-1.5 h-full">
              <span className="text-[10px] text-slate-600 italic">
                No active job
              </span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            {device.status === "online" || device.status === "busy" ? (
              <Wifi className="w-3.5 h-3.5 text-green-400" />
            ) : (
              <WifiOff className="w-3.5 h-3.5 text-slate-600" />
            )}
            <span className="text-[11px] text-slate-500 font-mono">
              {device.ip}
            </span>
          </div>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 px-2.5 text-xs text-slate-400 hover:text-white hover:bg-slate-700"
            onClick={() => openCommandModal(device.id)}
            disabled={device.status === "offline"}
          >
            <Terminal className="w-3 h-3 mr-1" />
            CMD
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
