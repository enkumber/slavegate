"use client";

import { useState } from "react";
import { Code, Webhook, Timer } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useStore } from "@/store";
import { cn } from "@/lib/utils";
import type { Tool, ToolType } from "@/lib/types";

const typeOptions = [
  {
    value: "script" as ToolType,
    label: "Script",
    icon: Code,
    description: "Run-once or manual script",
  },
  {
    value: "webhook" as ToolType,
    label: "Webhook",
    icon: Webhook,
    description: "Triggered by HTTP request",
  },
  {
    value: "scheduled" as ToolType,
    label: "Scheduled",
    icon: Timer,
    description: "Runs on a cron schedule",
  },
];

const defaultCode = `async function main() {
  // Your code here
  console.log('Tool started');
  
  // Do something useful...
  
  console.log('Done!');
}

main().catch(console.error);`;

export function NewToolModal() {
  const { newToolModalOpen, closeNewToolModal, addTool } = useStore();
  const [form, setForm] = useState({
    name: "",
    description: "",
    type: "script" as ToolType,
    schedule: "",
    webhookUrl: "",
    code: defaultCode,
  });

  const handleCreate = () => {
    if (!form.name.trim()) return;
    const tool: Tool = {
      id: `tool-${Date.now()}`,
      name: form.name,
      description: form.description,
      type: form.type,
      status: "active",
      lastRun: null,
      lastRunStatus: null,
      runCount: 0,
      code: form.code,
      schedule: form.schedule || undefined,
      webhookUrl: form.webhookUrl || undefined,
    };
    addTool(tool);
    closeNewToolModal();
    setForm({
      name: "",
      description: "",
      type: "script",
      schedule: "",
      webhookUrl: "",
      code: defaultCode,
    });
  };

  return (
    <Dialog open={newToolModalOpen} onOpenChange={closeNewToolModal}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>New Tool</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Name & Description */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs text-slate-400 mb-1.5 block">
                Tool Name *
              </Label>
              <Input
                placeholder="e.g. Instagram Auto-Poster"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs text-slate-400 mb-1.5 block">
                Type *
              </Label>
              <Select
                value={form.type}
                onValueChange={(v) =>
                  setForm({ ...form, type: v as ToolType })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {typeOptions.map((opt) => {
                    const Icon = opt.icon;
                    return (
                      <SelectItem key={opt.value} value={opt.value}>
                        <div className="flex items-center gap-2">
                          <Icon className="w-3.5 h-3.5" />
                          {opt.label}
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label className="text-xs text-slate-400 mb-1.5 block">
              Description
            </Label>
            <Input
              placeholder="What does this tool do?"
              value={form.description}
              onChange={(e) =>
                setForm({ ...form, description: e.target.value })
              }
            />
          </div>

          {/* Type-specific fields */}
          {form.type === "scheduled" && (
            <div>
              <Label className="text-xs text-slate-400 mb-1.5 block">
                Cron Schedule
              </Label>
              <Input
                placeholder="*/30 * * * * (every 30 min)"
                value={form.schedule}
                onChange={(e) => setForm({ ...form, schedule: e.target.value })}
                className="font-mono"
              />
              <p className="text-[11px] text-slate-600 mt-1">
                Standard cron syntax. Examples: <code className="text-slate-500">0 9 * * *</code> (daily 9am),{" "}
                <code className="text-slate-500">*/15 * * * *</code> (every 15min)
              </p>
            </div>
          )}

          {form.type === "webhook" && (
            <div>
              <Label className="text-xs text-slate-400 mb-1.5 block">
                Webhook URL
              </Label>
              <Input
                placeholder="https://hooks.your-domain.com/..."
                value={form.webhookUrl}
                onChange={(e) =>
                  setForm({ ...form, webhookUrl: e.target.value })
                }
                className="font-mono"
              />
            </div>
          )}

          {/* Code editor */}
          <div>
            <Label className="text-xs text-slate-400 mb-1.5 block">
              Code (JavaScript/TypeScript)
            </Label>
            <Textarea
              value={form.code}
              onChange={(e) => setForm({ ...form, code: e.target.value })}
              className="font-mono text-xs min-h-[200px] resize-y"
              spellCheck={false}
            />
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="ghost"
            size="sm"
            onClick={closeNewToolModal}
          >
            Cancel
          </Button>
          <Button
            size="sm"
            onClick={handleCreate}
            disabled={!form.name.trim()}
          >
            Create Tool
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
