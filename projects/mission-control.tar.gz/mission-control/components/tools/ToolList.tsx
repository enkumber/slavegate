"use client";

import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStore } from "@/store";
import { ToolCard } from "./ToolCard";

export function ToolList() {
  const { tools, openNewToolModal } = useStore();

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <div>
          <h2 className="text-sm font-semibold text-slate-300">
            Tools ({tools.length})
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {tools.filter((t) => t.status === "active").length} active
          </p>
        </div>
        <Button size="sm" className="h-8 text-xs" onClick={openNewToolModal}>
          <Plus className="w-3.5 h-3.5 mr-1.5" />
          New Tool
        </Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
        {tools.map((tool) => (
          <ToolCard key={tool.id} tool={tool} />
        ))}
      </div>
    </div>
  );
}
