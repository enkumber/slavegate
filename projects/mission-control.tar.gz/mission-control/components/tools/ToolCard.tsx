"use client";

import {
  Play,
  Clock,
  CheckCircle,
  XCircle,
  Code,
  Webhook,
  Timer,
  ToggleLeft,
  ToggleRight,
  History,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useStore } from "@/store";
import { formatTimeAgo, getStatusBg, cn } from "@/lib/utils";
import type { Tool, ToolType } from "@/lib/types";

const typeIcons: Record<ToolType, React.ElementType> = {
  script: Code,
  webhook: Webhook,
  scheduled: Timer,
};

const typeLabels: Record<ToolType, string> = {
  script: "Script",
  webhook: "Webhook",
  scheduled: "Scheduled",
};

interface ToolCardProps {
  tool: Tool;
}

export function ToolCard({ tool }: ToolCardProps) {
  const { updateTool } = useStore();
  const TypeIcon = typeIcons[tool.type];

  const handleToggle = () => {
    updateTool(tool.id, {
      status: tool.status === "active" ? "inactive" : "active",
    });
  };

  return (
    <Card className="border-slate-800 hover:border-slate-700 transition-colors">
      <CardContent className="p-4">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-start gap-2.5">
            <div className="w-8 h-8 bg-orange-500/10 border border-orange-500/20 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
              <TypeIcon className="w-4 h-4 text-orange-400" />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-white leading-tight">
                {tool.name}
              </p>
              <span className="text-[10px] text-orange-400 bg-orange-500/10 px-1.5 py-0.5 rounded mt-0.5 inline-block">
                {typeLabels[tool.type]}
              </span>
            </div>
          </div>
          <button
            onClick={handleToggle}
            className="text-slate-500 hover:text-white transition-colors flex-shrink-0"
            title={tool.status === "active" ? "Deactivate" : "Activate"}
          >
            {tool.status === "active" ? (
              <ToggleRight className="w-5 h-5 text-green-400" />
            ) : (
              <ToggleLeft className="w-5 h-5" />
            )}
          </button>
        </div>

        {/* Description */}
        <p className="text-xs text-slate-500 mb-3 line-clamp-2">
          {tool.description}
        </p>

        {/* Schedule / webhook url */}
        {tool.schedule && (
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 bg-slate-800/40 rounded px-2 py-1 mb-3 font-mono">
            <Timer className="w-3 h-3" />
            <span>{tool.schedule}</span>
          </div>
        )}
        {tool.webhookUrl && (
          <div className="text-[11px] text-slate-500 bg-slate-800/40 rounded px-2 py-1 mb-3 font-mono truncate">
            {tool.webhookUrl}
          </div>
        )}

        {/* Stats */}
        <div className="flex items-center gap-3 mb-3 text-[11px]">
          <div className="flex items-center gap-1 text-slate-500">
            <History className="w-3 h-3" />
            <span>{tool.runCount} runs</span>
          </div>
          {tool.lastRun && (
            <div className="flex items-center gap-1 text-slate-500">
              <Clock className="w-3 h-3" />
              <span>{formatTimeAgo(tool.lastRun)}</span>
            </div>
          )}
          {tool.lastRunStatus && (
            <div className="flex items-center gap-1">
              {tool.lastRunStatus === "success" ? (
                <>
                  <CheckCircle className="w-3 h-3 text-green-400" />
                  <span className="text-green-400">OK</span>
                </>
              ) : (
                <>
                  <XCircle className="w-3 h-3 text-red-400" />
                  <span className="text-red-400">Failed</span>
                </>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800">
          <span
            className={cn(
              "text-[10px] font-medium px-2 py-0.5 rounded border capitalize",
              getStatusBg(tool.status)
            )}
          >
            {tool.status}
          </span>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 px-2.5 text-xs text-slate-400 hover:text-white hover:bg-slate-700"
            disabled={tool.status !== "active"}
          >
            <Play className="w-3 h-3 mr-1" />
            Run
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
