"use client";

import { CheckCircle, XCircle, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { mockToolRuns } from "@/lib/mock-data";
import { formatTimeAgo, cn } from "@/lib/utils";

export function ToolRunHistory() {
  const sorted = [...mockToolRuns].sort(
    (a, b) =>
      new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()
  );

  return (
    <Card className="border-slate-800">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-slate-200">
          Recent Runs
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-0">
          {sorted.map((run) => (
            <div
              key={run.id}
              className="flex items-center gap-3 py-2.5 border-b border-slate-800/60 last:border-0"
            >
              {run.status === "success" ? (
                <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
              ) : (
                <XCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-200 font-medium truncate">
                  {run.toolName}
                </p>
                <p className="text-xs text-slate-500 truncate mt-0.5">
                  {run.output}
                </p>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0 text-[11px]">
                <div className="flex items-center gap-1 text-slate-500">
                  <Clock className="w-3 h-3" />
                  <span>{(run.duration / 1000).toFixed(1)}s</span>
                </div>
                <span className="text-slate-600">
                  {formatTimeAgo(run.startedAt)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
