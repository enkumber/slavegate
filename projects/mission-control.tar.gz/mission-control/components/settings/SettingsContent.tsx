"use client";

import { useState } from "react";
import {
  Server,
  Key,
  Bell,
  Palette,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  Copy,
  Check,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { useStore } from "@/store";
import { maskApiKey, formatTimeAgo } from "@/lib/utils";
import type { ApiKey } from "@/lib/types";

function ServerConfig() {
  const { settings, updateSettings } = useStore();
  const [editing, setEditing] = useState(false);
  const [url, setUrl] = useState(settings.serverUrl);
  const [ws, setWs] = useState(settings.wsEndpoint);

  const handleSave = () => {
    updateSettings({ serverUrl: url, wsEndpoint: ws });
    setEditing(false);
  };

  return (
    <Card className="border-slate-800">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Server className="w-4 h-4 text-blue-400" />
            <CardTitle className="text-sm font-semibold text-slate-200">
              Server Configuration
            </CardTitle>
          </div>
          {!editing && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-xs text-slate-400"
              onClick={() => setEditing(true)}
            >
              Edit
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="pt-0 space-y-3">
        <div>
          <Label className="text-xs text-slate-500 mb-1.5 block">
            Server URL
          </Label>
          {editing ? (
            <Input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="font-mono text-sm"
            />
          ) : (
            <p className="text-sm font-mono text-slate-300 bg-slate-800/40 px-3 py-2 rounded-md border border-slate-700">
              {settings.serverUrl}
            </p>
          )}
        </div>
        <div>
          <Label className="text-xs text-slate-500 mb-1.5 block">
            WebSocket Endpoint
          </Label>
          {editing ? (
            <Input
              value={ws}
              onChange={(e) => setWs(e.target.value)}
              className="font-mono text-sm"
            />
          ) : (
            <p className="text-sm font-mono text-slate-300 bg-slate-800/40 px-3 py-2 rounded-md border border-slate-700">
              {settings.wsEndpoint}
            </p>
          )}
        </div>
        {editing && (
          <div className="flex gap-2 pt-1">
            <Button size="sm" onClick={handleSave}>
              Save Changes
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setEditing(false);
                setUrl(settings.serverUrl);
                setWs(settings.wsEndpoint);
              }}
            >
              Cancel
            </Button>
          </div>
        )}
        {!editing && (
          <div className="flex items-center gap-2 pt-1">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-xs text-green-400">Connected</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function ApiKeyRow({ apiKey }: { apiKey: ApiKey }) {
  const { removeApiKey } = useStore();
  const [visible, setVisible] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(apiKey.value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex items-center gap-3 py-3 border-b border-slate-800/60 last:border-0">
      <div className="w-8 h-8 bg-slate-800 rounded-lg flex items-center justify-center flex-shrink-0">
        <Key className="w-3.5 h-3.5 text-slate-400" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-slate-200">{apiKey.name}</p>
        <p className="text-xs font-mono text-slate-500 mt-0.5">
          {visible ? apiKey.value : maskApiKey(apiKey.value)}
        </p>
        <p className="text-[11px] text-slate-600 mt-0.5">
          Created {formatTimeAgo(apiKey.createdAt)}
          {apiKey.lastUsed && (
            <> · Last used {formatTimeAgo(apiKey.lastUsed)}</>
          )}
        </p>
      </div>
      <div className="flex items-center gap-1 flex-shrink-0">
        <Button
          variant="ghost"
          size="icon"
          className="w-7 h-7 text-slate-500 hover:text-white"
          onClick={() => setVisible(!visible)}
        >
          {visible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="w-7 h-7 text-slate-500 hover:text-white"
          onClick={handleCopy}
        >
          {copied ? (
            <Check className="w-3.5 h-3.5 text-green-400" />
          ) : (
            <Copy className="w-3.5 h-3.5" />
          )}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="w-7 h-7 text-slate-500 hover:text-red-400"
          onClick={() => removeApiKey(apiKey.id)}
        >
          <Trash2 className="w-3.5 h-3.5" />
        </Button>
      </div>
    </div>
  );
}

function ApiKeysSection() {
  const { settings } = useStore();
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [newKey, setNewKey] = useState({ name: "", value: "" });
  const { updateSettings } = useStore();

  const handleAdd = () => {
    if (!newKey.name || !newKey.value) return;
    const key: ApiKey = {
      id: `key-${Date.now()}`,
      name: newKey.name,
      value: newKey.value,
      createdAt: new Date().toISOString(),
      lastUsed: null,
    };
    updateSettings({
      apiKeys: [...settings.apiKeys, key],
    });
    setAddModalOpen(false);
    setNewKey({ name: "", value: "" });
  };

  return (
    <>
      <Card className="border-slate-800">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Key className="w-4 h-4 text-yellow-400" />
              <CardTitle className="text-sm font-semibold text-slate-200">
                API Keys
              </CardTitle>
            </div>
            <Button
              size="sm"
              className="h-7 text-xs"
              onClick={() => setAddModalOpen(true)}
            >
              <Plus className="w-3 h-3 mr-1" />
              Add Key
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          {settings.apiKeys.length === 0 ? (
            <p className="text-sm text-slate-600 py-4 text-center italic">
              No API keys configured
            </p>
          ) : (
            settings.apiKeys.map((key) => (
              <ApiKeyRow key={key.id} apiKey={key} />
            ))
          )}
        </CardContent>
      </Card>

      <Dialog open={addModalOpen} onOpenChange={setAddModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add API Key</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-xs text-slate-400 mb-1.5 block">
                Key Name
              </Label>
              <Input
                placeholder="e.g. Instagram Graph API"
                value={newKey.name}
                onChange={(e) => setNewKey({ ...newKey, name: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs text-slate-400 mb-1.5 block">
                Key Value
              </Label>
              <Input
                type="password"
                placeholder="Paste your API key here..."
                value={newKey.value}
                onChange={(e) =>
                  setNewKey({ ...newKey, value: e.target.value })
                }
                className="font-mono"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setAddModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleAdd}
              disabled={!newKey.name || !newKey.value}
            >
              Add Key
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function NotificationPreferences() {
  const { settings, updateSettings } = useStore();

  const notifications = [
    {
      key: "deviceOffline" as const,
      label: "Device Offline",
      description: "Alert when a device disconnects unexpectedly",
    },
    {
      key: "jobFailed" as const,
      label: "Job Failed",
      description: "Notify when a job fails on any device",
    },
    {
      key: "newClient" as const,
      label: "New Client",
      description: "Notify when a new client is onboarded",
    },
    {
      key: "toolError" as const,
      label: "Tool Error",
      description: "Alert when a tool run fails",
    },
  ];

  return (
    <Card className="border-slate-800">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-purple-400" />
          <CardTitle className="text-sm font-semibold text-slate-200">
            Notifications
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent className="pt-0 space-y-4">
        {notifications.map((item, i) => (
          <div key={item.key}>
            {i > 0 && <Separator className="mb-4 bg-slate-800" />}
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-200">{item.label}</p>
                <p className="text-xs text-slate-500 mt-0.5">
                  {item.description}
                </p>
              </div>
              <Switch
                checked={settings.notifications[item.key]}
                onCheckedChange={(checked) =>
                  updateSettings({
                    notifications: {
                      ...settings.notifications,
                      [item.key]: checked,
                    },
                  })
                }
              />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function ThemeSettings() {
  const { settings, updateSettings } = useStore();

  return (
    <Card className="border-slate-800">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4 text-pink-400" />
          <CardTitle className="text-sm font-semibold text-slate-200">
            Appearance
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-200">Dark Mode</p>
            <p className="text-xs text-slate-500 mt-0.5">
              Dark theme for low-light environments
            </p>
          </div>
          <Switch
            checked={settings.theme === "dark"}
            onCheckedChange={(checked) =>
              updateSettings({ theme: checked ? "dark" : "light" })
            }
          />
        </div>
      </CardContent>
    </Card>
  );
}

export function SettingsContent() {
  return (
    <div className="max-w-2xl space-y-4">
      <ServerConfig />
      <ApiKeysSection />
      <NotificationPreferences />
      <ThemeSettings />
    </div>
  );
}
