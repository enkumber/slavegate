import { Header } from "@/components/layout/Header";
import { PageWrapper } from "@/components/layout/PageWrapper";
import { ToolList } from "@/components/tools/ToolList";
import { NewToolModal } from "@/components/tools/NewToolModal";
import { ToolRunHistory } from "@/components/tools/ToolRunHistory";

export default function ToolsPage() {
  return (
    <>
      <Header
        title="Tool Builder"
        subtitle="Custom automation tools and scripts"
      />
      <PageWrapper>
        <ToolList />
        <ToolRunHistory />
        <NewToolModal />
      </PageWrapper>
    </>
  );
}
