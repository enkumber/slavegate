import { Header } from "@/components/layout/Header";
import { PageWrapper } from "@/components/layout/PageWrapper";
import { ClientList } from "@/components/agency/ClientList";
import { TaskQueue } from "@/components/agency/TaskQueue";

export default function AgencyPage() {
  return (
    <>
      <Header
        title="Agency"
        subtitle="Client management and content operations"
      />
      <PageWrapper>
        <ClientList />
        <TaskQueue />
      </PageWrapper>
    </>
  );
}
