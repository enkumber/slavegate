import { Header } from "@/components/layout/Header";
import { PageWrapper } from "@/components/layout/PageWrapper";
import { StatsCards } from "@/components/dashboard/StatsCards";
import { ActivityFeed } from "@/components/dashboard/ActivityFeed";
import { ProjectGrid } from "@/components/dashboard/ProjectGrid";
import { JobsChart, UptimeChart } from "@/components/dashboard/JobsChart";

export default function DashboardPage() {
  return (
    <>
      <Header
        title="Dashboard"
        subtitle="Overview of all projects and systems"
      />
      <PageWrapper>
        <StatsCards />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Left column */}
          <div className="lg:col-span-2 space-y-5">
            <JobsChart />
            <ProjectGrid />
          </div>

          {/* Right column */}
          <div className="space-y-5">
            <UptimeChart />
            <ActivityFeed />
          </div>
        </div>
      </PageWrapper>
    </>
  );
}
