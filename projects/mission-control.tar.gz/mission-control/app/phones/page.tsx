import { Header } from "@/components/layout/Header";
import { PageWrapper } from "@/components/layout/PageWrapper";
import { DeviceList } from "@/components/phones/DeviceList";
import { JobQueue } from "@/components/phones/JobQueue";
import { CommandModal } from "@/components/phones/CommandModal";
import { LogsPanel } from "@/components/phones/LogsPanel";

export default function PhonesPage() {
  return (
    <>
      <Header
        title="Phone Network"
        subtitle="Device management and job orchestration"
      />
      <PageWrapper>
        <DeviceList />
        <JobQueue />
        <LogsPanel />
        <CommandModal />
      </PageWrapper>
    </>
  );
}
