import { Header } from "@/components/layout/Header";
import { PageWrapper } from "@/components/layout/PageWrapper";
import { SettingsContent } from "@/components/settings/SettingsContent";

export default function SettingsPage() {
  return (
    <>
      <Header title="Settings" subtitle="System configuration and preferences" />
      <PageWrapper>
        <SettingsContent />
      </PageWrapper>
    </>
  );
}
