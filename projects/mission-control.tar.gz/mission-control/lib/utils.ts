import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatTimeAgo(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSeconds = Math.floor(diffMs / 1000);
  const diffMinutes = Math.floor(diffSeconds / 60);
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSeconds < 60) return `${diffSeconds}s ago`;
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  return `${diffDays}d ago`;
}

export function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  if (minutes < 60) return `${minutes}m ${remainingSeconds}s`;
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  return `${hours}h ${remainingMinutes}m`;
}

export function formatDateTime(dateString: string): string {
  return new Date(dateString).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function maskApiKey(key: string): string {
  if (key.length <= 8) return "••••••••";
  return key.substring(0, 4) + "••••••••" + key.substring(key.length - 4);
}

export function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    online: "text-green-400",
    offline: "text-slate-500",
    busy: "text-yellow-400",
    error: "text-red-400",
    pending: "text-slate-400",
    running: "text-blue-400",
    done: "text-green-400",
    failed: "text-red-400",
    active: "text-green-400",
    onboarding: "text-yellow-400",
    paused: "text-slate-500",
    success: "text-green-400",
    failure: "text-red-400",
    inactive: "text-slate-500",
  };
  return colors[status] ?? "text-slate-400";
}

export function getStatusBg(status: string): string {
  const colors: Record<string, string> = {
    online: "bg-green-500/10 text-green-400 border-green-500/20",
    offline: "bg-slate-500/10 text-slate-400 border-slate-500/20",
    busy: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
    error: "bg-red-500/10 text-red-400 border-red-500/20",
    pending: "bg-slate-500/10 text-slate-400 border-slate-500/20",
    running: "bg-blue-500/10 text-blue-400 border-blue-500/20",
    done: "bg-green-500/10 text-green-400 border-green-500/20",
    failed: "bg-red-500/10 text-red-400 border-red-500/20",
    active: "bg-green-500/10 text-green-400 border-green-500/20",
    onboarding: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
    paused: "bg-slate-500/10 text-slate-400 border-slate-500/20",
    success: "bg-green-500/10 text-green-400 border-green-500/20",
    failure: "bg-red-500/10 text-red-400 border-red-500/20",
    inactive: "bg-slate-500/10 text-slate-400 border-slate-500/20",
    todo: "bg-slate-500/10 text-slate-400 border-slate-500/20",
    in_progress: "bg-blue-500/10 text-blue-400 border-blue-500/20",
    blocked: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  };
  return colors[status] ?? "bg-slate-500/10 text-slate-400 border-slate-500/20";
}

export function getSeverityColor(severity: string): string {
  const colors: Record<string, string> = {
    info: "text-blue-400",
    warning: "text-yellow-400",
    error: "text-red-400",
    success: "text-green-400",
  };
  return colors[severity] ?? "text-slate-400";
}
