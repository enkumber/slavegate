// Device types
export type DeviceStatus = "online" | "offline" | "busy" | "error";

export interface Device {
  id: string;
  name: string;
  model: string;
  status: DeviceStatus;
  lastSeen: string;
  currentJob: string | null;
  battery: number;
  ip: string;
  os: string;
  uptime: number; // hours
}

// Job types
export type JobStatus = "pending" | "running" | "done" | "failed";

export interface Job {
  id: string;
  name: string;
  deviceId: string;
  deviceName: string;
  status: JobStatus;
  createdAt: string;
  startedAt: string | null;
  completedAt: string | null;
  duration: number | null; // seconds
  output: string | null;
  error: string | null;
}

// Client types
export type ClientStatus = "active" | "onboarding" | "paused";

export interface Client {
  id: string;
  name: string;
  company: string;
  status: ClientStatus;
  platforms: string[];
  strategyStatus: "approved" | "draft" | "review";
  nextScheduledPost: string | null;
  monthlyPosts: number;
  completedPosts: number;
  avatar: string;
}

// Task types
export type TaskStatus = "todo" | "in_progress" | "done" | "blocked";
export type TaskPriority = "low" | "medium" | "high" | "urgent";

export interface Task {
  id: string;
  title: string;
  clientId: string;
  clientName: string;
  status: TaskStatus;
  priority: TaskPriority;
  dueDate: string;
  assignedTo: string;
  platform: string;
}

// Tool types
export type ToolType = "script" | "webhook" | "scheduled";
export type ToolStatus = "active" | "inactive" | "error";

export interface Tool {
  id: string;
  name: string;
  description: string;
  type: ToolType;
  status: ToolStatus;
  lastRun: string | null;
  lastRunStatus: "success" | "failure" | null;
  runCount: number;
  code: string;
  schedule?: string;
  webhookUrl?: string;
}

export interface ToolRun {
  id: string;
  toolId: string;
  toolName: string;
  startedAt: string;
  completedAt: string;
  status: "success" | "failure";
  duration: number; // ms
  output: string;
}

// Activity types
export type ActivityType =
  | "device_online"
  | "device_offline"
  | "job_started"
  | "job_completed"
  | "job_failed"
  | "client_added"
  | "task_created"
  | "task_completed"
  | "tool_run"
  | "alert"
  | "system";

export interface Activity {
  id: string;
  type: ActivityType;
  title: string;
  description: string;
  timestamp: string;
  project: "phones" | "agency" | "tools" | "system";
  severity: "info" | "warning" | "error" | "success";
}

// Stats types
export interface DailyJobStat {
  date: string;
  pending: number;
  running: number;
  done: number;
  failed: number;
}

export interface UptimeStat {
  device: string;
  uptime: number; // percentage
}

// Settings types
export interface ApiKey {
  id: string;
  name: string;
  value: string;
  createdAt: string;
  lastUsed: string | null;
}

export interface Settings {
  serverUrl: string;
  wsEndpoint: string;
  notifications: {
    deviceOffline: boolean;
    jobFailed: boolean;
    newClient: boolean;
    toolError: boolean;
  };
  theme: "dark" | "light";
  apiKeys: ApiKey[];
}
